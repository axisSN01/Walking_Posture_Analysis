#!/usr/bin/python -d
# -*- coding: utf-8 -*-
import pykinect
from pykinect import nui
import time
import cv
import threading
import array

VIDEO_WINSIZE = (640,480)

dic={"ipl":cv.CreateImage(VIDEO_WINSIZE, cv.IPL_DEPTH_8U, 4)}
dic["ipl"]=cv.LoadImage('ipl.jpg')

class cv_thread(threading.Thread):
    def __init__(self):
        super(cv_thread, self).__init__()
 
    def run(self):
        global dic
        cv.NamedWindow("ventana") 
        while True:
            time.sleep(0.5)
            threadLock.acquire()      
            try:
                cv.ShowImage("ventana", dic["ipl"])               
            except: 
                print('error en showimage')            
            threadLock.release() 
               
class ki_thread(threading.Thread):
    def __init__(self):
        super(ki_thread, self).__init__()
        self.ipl_mat= array.array('c') # creo un arreglo tipo char de 1 byte cada elemento
        self.ipl_mat.fromstring(dic["ipl"].tostring()) # llevo ipl a cadena, y de cadena a array
        self.address = self.ipl_mat.buffer_info()[0] # buffer info= adrees y llntgh in register size
        self.frame=pykinect.nui.structs.ImageFrame()
    def run(self):
        global dic    
        threadLock.acquire() # tomo el lock para el seteo
        self.kinect = nui.Runtime()
        #self.kinect.skeleton_engine.enabled = True        
        self.kinect.video_stream.open(nui.ImageStreamType.Video, 2, nui.ImageResolution.Resolution640x480, nui.ImageType.Color)
        threadLock.release()
        while True:
            time.sleep(0.5) 
            threadLock.acquire() # tomo el lock para el seteo            
            try:
                self.frame = kinect.video_stream.get_next_frame(30)
                frame.image.copy_bits(self.address) # copio bits de frame en la dreccion adress de ipl_mat, estructura tipo ipl evidentemente.
                cv.SetData(dic["ipl"], self.ipl_mat.tostring()) # asigno lo que halla en ipl_mat a ipl. 
                kinect._nui.NuiImageStreamReleaseFrame(kinect.video_stream._stream, self.frame)        
            except :
                print ('error en kinect')

            threadLock.release()
            
if __name__ == '__main__':
    threadLock = threading.Lock()
    #t1 = ki_thread()
    t2 = cv_thread()
    #t1.start()
    t2.start()
    #t1.join()
    #t2.join()
