from distutils.core import setup
import py2exe

mis_iconos = [('iconos', ['D:\YAGUI\PROYECTO LAB MARCHAS\Pasos del proyecto\work_folder\iconos\config.png']),
              ('iconos', ['D:\YAGUI\PROYECTO LAB MARCHAS\Pasos del proyecto\work_folder\iconos\datos.png']),
              ('iconos', ['D:\YAGUI\PROYECTO LAB MARCHAS\Pasos del proyecto\work_folder\iconos\curva.png']),
              ('iconos', ['D:\YAGUI\PROYECTO LAB MARCHAS\Pasos del proyecto\work_folder\iconos\iniciar.png']),
              ('iconos', ['D:\YAGUI\PROYECTO LAB MARCHAS\Pasos del proyecto\work_folder\iconos\cam.png']),
              ('iconos', ['D:\YAGUI\PROYECTO LAB MARCHAS\Pasos del proyecto\work_folder\iconos\UNNe1.gif']),             
              ('iconos', ['D:\YAGUI\PROYECTO LAB MARCHAS\Pasos del proyecto\work_folder\iconos\UNNe2.jpg'])
              ]
              #('phonon_backend', ['C:\Python27\Lib\site-packages\PyQt4\plugins\phonon_backend\phonon_ds94.dll'])            
                #]

setup(windows=[{"script": "multi_thread.py"}], 
        data_files = mis_iconos,
        options={"py2exe":{"includes":["sip"], "bundle_files": 3, "compressed": False}}
        )
