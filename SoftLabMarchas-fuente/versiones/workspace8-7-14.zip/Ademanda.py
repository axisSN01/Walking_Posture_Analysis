#!/usr/bin/python -d
# -*- coding: utf-8 -*-
import pykinect
from pykinect import nui
import time
import cv
import threading
import array

VIDEO_WINSIZE = (640,480)
frame_copy = cv.CreateImage(VIDEO_WINSIZE, cv.IPL_DEPTH_8U, 4)
ipl = cv.CreateImage(VIDEO_WINSIZE, cv.IPL_DEPTH_8U, 4) # creo imagen tipo intel image procesing libray (estructura), reservo espacio .
ipl_mat = array.array('c') # creo un arreglo tipo char de 1 byte cada elemento
ipl_mat.fromstring(ipl.tostring()) # llevo ipl a cadena, y de cadena a arreglo.
address = ipl_mat.buffer_info()[0] # buffer info= adrees y llntgh in register size
threadLock=threading.Lock()
cv.NamedWindow("Kinect")
kinect = nui.Runtime()
kinect.video_stream.open(nui.ImageStreamType.Video, 2, nui.ImageResolution.Resolution640x480, nui.ImageType.Color)
inicio=time.clock()
while True:
    time.sleep(1)
    seconds=time.clock()-inicio
    if seconds>10:
        threadLock.acquire()      
        try:
            frame = kinect.video_stream.get_next_frame(30)
            frame.image.copy_bits(address) # copio bits de frame en la dreccion adress de ipl_mat, estructura tipo ipl evidentemente.
            cv.SetData(ipl, ipl_mat.tostring()) # asigno lo que halla en ipl_mat a ipl.
            #cv.SaveImage('ipl.jpg',ipl)  # muestro ipl, y el buffer de la kinect se actualiza solo   
            print frame 
            kinect._nui.NuiImageStreamReleaseFrame(kinect.video_stream._stream, frame)        

        except :
            print ('error')
            pass
        threadLock.release() 
        
    threadLock.acquire()            
    cv.ShowImage("Kinect", ipl)
    threadLock.release()    
    print seconds        