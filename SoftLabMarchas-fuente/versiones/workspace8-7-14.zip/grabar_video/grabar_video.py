#!/usr/bin/python -d
# -*- coding: utf-8 -*-
import cv, threading
import time, sys, os

Nframes=50
ipl_list=range(0,50)

class grab_thread(threading.Thread):
    def __init__(self):
        super(grab_thread, self).__init__()

    def run(self):
        i=0
        writer = cv.CreateVideoWriter('prueba.avi', cv.CV_FOURCC('X','V','I','D'), 7, (640,480), 1)        
        print "grabando en thread"
        
        for i in range(0,50):
            ipl_list[i]=cv.LoadImage("ipl"+str(i)+".jpg")        
        
        for i in range(0,Nframes):   
            cv.WriteFrame(writer, ipl_list[i])
         
        del(writer)
        
        print "grabado completo en thread"     


if __name__ == "__main__":
    t1=grab_thread()
    t1.start()