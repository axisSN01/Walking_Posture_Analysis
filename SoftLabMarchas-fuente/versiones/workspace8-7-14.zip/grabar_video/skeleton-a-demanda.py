#!/usr/bin/python -d
# -*- coding: utf-8 -*-
import pykinect
from pykinect import nui
import time,pdb
import cv
from pykinect.nui import JointId

kinect = nui.Runtime()
kinect.skeleton_engine.enabled = True    
#kinect.video_stream.open(nui.ImageStreamType.Video, 2, nui.ImageResolution.Resolution640x480, nui.ImageType.Color)
while True:
    time.sleep(1)          
    SkFrame = kinect.skeleton_engine.get_next_frame()              
    for index, data in enumerate(SkFrame.SkeletonData):
        if  data.eTrackingState != nui.SkeletonTrackingState.NOT_TRACKED:
            pdb.set_trace()
            HeadPos = nui.SkeletonEngine.skeleton_to_depth_image(data.SkeletonPositions[JointId.Head], 640, 480)
            #guardo datos de tobillos, para cada skeleto encontrado(sobreescribo si hay varios)      
            BILLO_IZ= data.SkeletonPositions[JointId.AnkleLeft]
            pdb.set_trace()
           
        print data