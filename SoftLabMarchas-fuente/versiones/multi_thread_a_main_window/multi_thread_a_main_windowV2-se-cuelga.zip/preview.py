#!/usr/bin/python -d
#-*- coding: utf-8 -*-
 
import sys, numpy
from PyQt4 import QtCore, QtGui, phonon
from ventana1 import Ui_ventana
from curvas import Ui_curvas
from videoPlayer import Ui_video
import ventana1,curvas,videoPlayer
from ConfigParser import RawConfigParser
import pdb
import time

class Aplicacion(QtGui.QMainWindow):
    def __init__(self, parent=None):
        QtGui.QWidget.__init__(self, parent)
        self.ui = Ui_ventana()
        self.ui.setupUi(self)
        self.center()
#------------signals and slots--------------------------------------------------- 
        self.ui.tabWidget.setCurrentWidget(self.ui.tabIni)
        self.ui.actionCerrar.triggered.connect(self.cerrar)
        self.ui.bot_conf.clicked.connect(self.ir_conf)
        self.ui.bot_curvas.clicked.connect(self.ver_curvas)
        self.ui.bot_video.clicked.connect(self.ver_video)
        self.ui.bot_ini.clicked.connect(self.iniciar)   
#------------------------------------------------------------------------------- 
        try:
            self.capture = cv.CreateCameraCapture(-1) #monto kinect 
            #cv.SetCaptureProperty(self.capture,cv.CV_CAP_PROP_BRIGHTNESS,0.5)
        except:
            self.ui.consola.append(">>>Kinect no detectada (reinicie)\n")       
              
#-----------------------------------------------------------------------------

    def center(self):
        screen = QtGui.QDesktopWidget().screenGeometry()
        size =  self.geometry()
        self.move((screen.width()-size.width())/2, (screen.height()-size.height())/2)
#-----------------------------------------------------------------------------        
    def ir_conf(self):
        self.ui.tabWidget.setCurrentWidget(self.ui.tabConf)  # cambia tab a configuracion

#-----------------------------------------------------------------------------
    def ver_curvas(self):
        if  self.ui.bot_curvas.isChecked(): 
            self.wid_curvas=curvas()          
            self.wid_curvas.show()
        if not self.ui.bot_curvas.isChecked():  
            self.wid_curvas.close()
#-----------------------------------------------------------------------------
    def ver_video(self):
        media = phonon.Phonon.MediaSource('Trailer480.mp4')
        if  self.ui.bot_video.isChecked(): 
            self.wid_video=video()
            self.wid_video.video.videoPlayer.load(media)
            self.wid_video.show()
            #self.wid_video.video.videoPlayer.play()
            #QtCore.QObject.connect(self.wid_video, self.wid_video.closeEvent(QtGui.QcloseEvent), self.videoPlayer.stop)                   
        if not self.ui.bot_video.isChecked():
            #self.wid_video.video.videoPlayer.stop()
            self.wid_video.close()
#-----------------------------------------------------------------------------

    def cerrar(self): 
        reply = QtGui.QMessageBox.question(self, "Salir?",
                QtGui.QApplication.translate("Aplicacion 1", "Desea cerrar la aplicacion?", None, QtGui.QApplication.UnicodeUTF8),
                QtGui.QMessageBox.Yes | QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes:
            self.close()
        if reply == QtGui.QMessageBox.No:
            pass
#-----------------------------------------------------------------------------

    def iniciar(self): 
        pass
#-----------------------------------------------------------------------------

class curvas(QtGui.QWidget):
    def __init__(self):
        QtGui.QWidget.__init__(self)
        self.curvas = Ui_curvas()
        self.curvas.setupUi(self)
        
class video(QtGui.QWidget):
    def __init__(self):
        QtGui.QWidget.__init__(self)
        self.video = Ui_video()
        self.video.setupUi(self)
        
"""if __name__ == "__main__":
    app = QtGui.QApplication(sys.argv)
    app.setStyle("plastique")
    a = Aplicacion()
    a.show()
    sys.exit(app.exec_())"""
