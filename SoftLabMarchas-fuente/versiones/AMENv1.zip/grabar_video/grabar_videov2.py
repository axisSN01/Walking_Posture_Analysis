#!/usr/bin/python -d
# -*- coding: utf-8 -*-
import cv
import time, sys, os


ipl_list=range(0,50)
writer = cv.CreateVideoWriter('out.AVI', cv.CV_FOURCC('X','V','I','D'), 15, (640,480), 1)
i=0
for i in range(0,50):
    ipl_list[i]=cv.LoadImage("ipl"+str(i)+".jpg")

for i in range(0,50):
    cv.WriteFrame(writer,ipl_list[i])
    
del(writer)